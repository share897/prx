# Kaliyankattu Yakshi — Malayalam Ghost 3.0

A clean, blue, ghost-themed local proxy manager for Brave/Chromium.

## Brave installation

1. Extract this ZIP to a normal folder.
2. Open `brave://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the **extracted folder that directly contains `manifest.json`**. Do not select the ZIP file itself.
6. Pin **Kaliyankattu Yakshi** from the extensions menu.

If Brave reports an error, open the extension's **Errors** page on `brave://extensions` and reload the extension after fixing the reported issue.

## What was changed

- Rebranded to **Kaliyankattu Yakshi — Malayalam Ghost**.
- Added the blue Yakshi portrait as the extension icon in 16/32/48/128px sizes.
- Refreshed the popup, storage, settings, and monitor branding.
- Removed the unnecessary `tabs` permission; creating extension tabs does not require access to tab contents.
- Replaced broad `<all_urls>` host access with only the two hosts used by the health/speed checks: `api.ipify.org` and `speed.cloudflare.com`.
- Kept `proxy`, `storage`, `alarms`, and `notifications`, which are used by the extension's actual features.
- Fixed **CHECK** so it validates without replacing saved storage.
- Hardened **LOAD SAVED** and **SAVE TO STORAGE** with error handling and button-state protection.
- Updated the extension version to 3.0.0.

## Server format

`protocol://host:port | country | uptime | anonymity`

Examples:

```text
socks5://1.2.3.4:1080 | United States | 100 | Elite
http://5.6.7.8:8080 | Germany | 95 | Anonymous
socks4://9.10.11.12:4145 | Greece | 100 | Elite
```

Supported protocols: HTTP, HTTPS, SOCKS4, SOCKS5. Maximum local pool: 77.

The extension is intended for proxies you own or are authorized to use.
