/* Kaliyankattu Yakshi 3.0 — Malayalam ghost-themed proxy manager. */
const api = globalThis.browser ?? globalThis.chrome;
const IS_FIREFOX = typeof globalThis.browser !== "undefined";

const DEFAULTS = {
  enabled: false, activeId: null, proxies: [], hotIds: [], selectedCountry: "ALL",
  settings: { timeoutMs: 4500, reminderHours: 2, topCount: 7, maxImport: 77, testBatch: 7, autoFailover: true, autoRotate: false },
  reminder: { lastChanged: 0, lastNotified: 0 },
  monitor: { lastRun: 0, publicIp: "—", country: "—", latency: null, speedMbps: null, message: "idle" }
};
const TYPES = ["http", "https", "socks4", "socks5"];
const uid = () => globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
const num = v => Number.isFinite(Number(v));

function normalize(p) {
  if (!p || !String(p.host || "").trim() || !num(p.port)) return null;
  let type = String(p.type || p.protocol || "http").toLowerCase().replace(/:$/, "");
  const port = Number(p.port);
  if (!TYPES.includes(type) || port < 1 || port > 65535) return null;
  return {
    id: p.id || uid(), type, host: String(p.host).trim(), port,
    country: String(p.country || "—").trim() || "—", anonymity: String(p.anonymity || "—").trim() || "—",
    uptime: num(p.uptime) ? Number(p.uptime) : null, sourceSpeed: num(p.sourceSpeed) ? Number(p.sourceSpeed) : null,
    username: String(p.username || ""), password: String(p.password || ""),
    status: ["online", "failed", "testing"].includes(p.status) ? p.status : "unknown",
    latency: num(p.latency) ? Number(p.latency) : null, speedMbps: num(p.speedMbps) ? Number(p.speedMbps) : null,
    failures: Number(p.failures) || 0, lastChecked: Number(p.lastChecked) || 0, error: String(p.error || "")
  };
}
async function getState() {
  const raw = await api.storage.local.get(DEFAULTS);
  const s = { ...DEFAULTS, ...raw };
  s.proxies = (Array.isArray(raw.proxies) ? raw.proxies : []).map(normalize).filter(Boolean).slice(0,77);
  s.hotIds = Array.isArray(raw.hotIds) ? raw.hotIds.filter(Boolean) : [];
  s.settings = { ...DEFAULTS.settings, ...(raw.settings || {}) };
  s.reminder = { ...DEFAULTS.reminder, ...(raw.reminder || {}) };
  s.monitor = { ...DEFAULTS.monitor, ...(raw.monitor || {}) };
  return s;
}
async function saveState(s) { await api.storage.local.set(s); }
function pkey(p) { return `${p.type}|${p.host.toLowerCase()}|${p.port}|${p.username || ""}`; }
function chromeConfig(p) { return { mode: "fixed_servers", rules: { singleProxy: { scheme: p.type, host: p.host, port: p.port }, bypassList: ["<local>"] } }; }
function firefoxConfig(p) {
  if (p.type === "socks4" || p.type === "socks5") return { proxyType:"manual", socks:`${p.host}:${p.port}`, socksVersion:p.type === "socks4" ? 4 : 5, proxyDNS:p.type === "socks5", passthrough:"<local>" };
  return { proxyType:"manual", http:`${p.host}:${p.port}`, ssl:`${p.host}:${p.port}`, httpProxyAll:true, passthrough:"<local>" };
}
async function setBrowserProxy(p) {
  if (!api.proxy?.settings) throw new Error("This browser does not expose the proxy settings API.");
  return p ? api.proxy.settings.set({ value: IS_FIREFOX ? firefoxConfig(p) : chromeConfig(p) }) : api.proxy.settings.clear({});
}
const countryMap={US:"United States",DE:"Germany",KR:"South Korea",PH:"Philippines",GR:"Greece",AT:"Austria",JP:"Japan",HK:"Hong Kong",IR:"Iran",VN:"Vietnam",CN:"China",SG:"Singapore",GB:"United Kingdom",CA:"Canada",FR:"France",NL:"Netherlands",IN:"India",MX:"Mexico",EG:"Egypt"};
function countryName(v){const s=String(v||"").trim(); return countryMap[s.toUpperCase()]||s||"—";}
function findCountry(text){const s=String(text||"");const m=s.match(/\[([A-Z]{2})\]/i)||s.match(/\b(US|DE|KR|PH|GR|AT|JP|HK|IR|VN|CN|SG|GB|CA|FR|NL|IN|MX|EG)\b/i);return m?countryName(m[1]):"—";}
function findAnonymity(text){const m=String(text||"").match(/\b(Elite|Anonymous|Transparent)\b/i);return m?m[1][0].toUpperCase()+m[1].slice(1).toLowerCase():"—";}
function findUptime(text){const m=String(text||"").match(/\b(\d{1,3})\s*%/);return m?Number(m[1]):null;}
function findSpeed(text){const m=String(text||"").match(/\b(\d+(?:\.\d+)?)\s*ms\b/i);return m?Number(m[1]):null;}
function parseEndpoint(line, fallbackType="") {
  const raw=String(line||"").trim(); if(!raw||/^#/.test(raw)) return null;
  const match=raw.match(/(?:(http|https|socks4|socks5):\/\/)?((?:\d{1,3}\.){3}\d{1,3}|[a-z0-9.-]+):(\d{1,5})(?::([^:\s|]+):([^\s|]+))?/i);
  if(!match) return null;
  let type=String(match[1]||fallbackType||"http").toLowerCase(); if(!TYPES.includes(type)) type="http";
  return normalize({type,host:match[2],port:Number(match[3]),username:match[4]||"",password:match[5]||"",country:findCountry(raw),anonymity:findAnonymity(raw),uptime:findUptime(raw),sourceSpeed:findSpeed(raw)});
}
function parseManualText(text) {
  const out=[],seen=new Set(); let invalid=0;
  for(const line0 of String(text||"").replace(/\uFEFF/g,"").split(/\r?\n/)) {
    const line=line0.trim(); if(!line) continue;
    const fields=line.split("|").map(x=>x.trim());
    const endpoint=fields[0];
    const fallback=(endpoint.match(/^(http|https|socks4|socks5):\/\//i)||[])[1]||"";
    const candidates=endpoint.match(/(?:(?:https?|socks4|socks5):\/\/)?(?:\d{1,3}\.){3}\d{1,3}:\d{1,5}(?::[^\s,:|]+(?::[^\s,|]+)?)?/gi)||[];
    const list=candidates.length?candidates:[endpoint];
    for(const c of list){
      const p=parseEndpoint(c,fallback); if(!p){invalid++;continue;}
      if(fields[1]) p.country=countryName(fields[1]);
      if(fields[2] && num(fields[2])) p.uptime=Number(fields[2]);
      if(fields[3]) p.anonymity=fields[3];
      const k=pkey(p); if(!seen.has(k)){seen.add(k);out.push(p);}
    }
  }
  return {proxies:out,invalid};
}
async function replaceFromText(text){
  const parsed=parseManualText(text), out=[], seen=new Set();
  for(const p of parsed.proxies){if(out.length>=77)break;const k=pkey(p);if(!seen.has(k)){seen.add(k);out.push(p);}}
  const s=await getState();
  if(s.activeId) { try{await setBrowserProxy(null);}catch{} }
  s.proxies=out;s.hotIds=[];s.activeId=null;s.enabled=false;
  await saveState(s); return {ok:true,added:out.length,invalid:parsed.invalid,capped:parsed.proxies.length>77,total:out.length};
}
async function addProxy(proxy){const s=await getState(),p=normalize(proxy);if(!p)return{ok:false,error:"Invalid server. Use protocol + host + port."};const k=pkey(p),old=s.proxies.find(x=>pkey(x)===k);if(old)return{ok:true,duplicate:true,proxy:old};if(s.proxies.length>=77)return{ok:false,error:"Maximum storage is 77 servers."};s.proxies.push(p);await saveState(s);return{ok:true,duplicate:false,proxy:p};}
async function measureSpeed(){
  const started=performance.now(), ctl=new AbortController(), timer=setTimeout(()=>ctl.abort(),2500);
  try{const r=await fetch("https://speed.cloudflare.com/__down?bytes=131072",{cache:"no-store",signal:ctl.signal});const b=await r.arrayBuffer();const sec=Math.max((performance.now()-started)/1000,0.05);return (b.byteLength*8/sec/1000000);}catch{return null}finally{clearTimeout(timer);}
}
async function probe(id,activate=false){
  const s=await getState(),p=s.proxies.find(x=>x.id===id);if(!p)return{ok:false,error:"Server not found"};
  p.status="testing";p.error="";await saveState(s);
  try{
    if(activate)await setBrowserProxy(p);
    const started=performance.now(),ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),Number(s.settings.timeoutMs)||4500);
    let response;try{response=await fetch("https://api.ipify.org?format=json",{cache:"no-store",signal:ctl.signal});}finally{clearTimeout(timer);}
    if(!response.ok)throw new Error(`probe HTTP ${response.status}`);const data=await response.json();const latency=Math.round(performance.now()-started);const speed=await measureSpeed();
    const ss=await getState(),q=ss.proxies.find(x=>x.id===id);if(q){q.status="online";q.latency=latency;q.speedMbps=speed;q.failures=0;q.lastChecked=Date.now();q.error="";}
    ss.monitor={...ss.monitor,lastRun:Date.now(),publicIp:data?.ip||"—",country:q?.country||"—",latency,speedMbps:speed,message:"connected"};
    if(activate){ss.enabled=true;ss.activeId=id;ss.reminder.lastChanged=Date.now();ss.reminder.lastNotified=Date.now();}
    await saveState(ss);return{ok:true,proxy:q};
  }catch(e){const ss=await getState(),q=ss.proxies.find(x=>x.id===id);if(q){q.status="failed";q.failures=(q.failures||0)+1;q.lastChecked=Date.now();q.error=e?.name==="AbortError"?"timeout":String(e?.message||e);}await saveState(ss);return{ok:false,error:q?.error||"connection failed",proxy:q};}
}
function score(p){if(p.status!=="online")return-1;return (Number(p.speedMbps)||0)*100-(Number(p.latency)||99999)-(Number(p.failures)||0)*500;}
async function testTop(count=7,country="ALL",limit=77){
  const s=await getState(),original=s.activeId?s.proxies.find(p=>p.id===s.activeId):null,wasEnabled=!!s.enabled;
  const target=Math.max(1,Math.min(77,Number(limit)||77)),n=Math.max(1,Math.min(77,Number(count)||7));
  const eligible=s.proxies.filter(p=>country==="ALL"||p.country===country).slice(0,target);let tested=0;
  for(const p of eligible){await probe(p.id,true);tested++;}
  const fresh=await getState();
  if(original){try{await setBrowserProxy(original);}catch{}fresh.activeId=original.id;fresh.enabled=wasEnabled;}else{try{await setBrowserProxy(null);}catch{}fresh.activeId=null;fresh.enabled=false;}
  fresh.hotIds=fresh.proxies.filter(p=>country==="ALL"||p.country===country).filter(p=>p.status==="online").sort((a,b)=>score(b)-score(a)).slice(0,n).map(p=>p.id);await saveState(fresh);
  return{hot:fresh.proxies.filter(p=>fresh.hotIds.includes(p.id)),tested};
}
async function activate(id){return probe(id,true);}
async function chooseTop(){const s=await getState(),hot=s.proxies.filter(p=>s.hotIds.includes(p.id)).sort((a,b)=>score(b)-score(a));for(const p of hot){const r=await activate(p.id);if(r.ok)return r;}return{ok:false,error:"No working server in the Fast Pool."};}
async function disable(){const s=await getState();await setBrowserProxy(null);s.enabled=false;s.activeId=null;s.monitor.message="direct";await saveState(s);return s;}
function countries(s){const map={};for(const p of s.proxies){const c=p.country||"—";if(!map[c])map[c]={country:c,count:0,online:0};map[c].count++;if(p.status==="online")map[c].online++;}return Object.values(map).sort((a,b)=>b.count-a.count);}
function storageText(s){return s.proxies.map(p=>{const auth=(p.username&&p.password)?`:${p.username}:${p.password}`:"";return `${p.type}://${p.host}:${p.port}${auth} | ${p.country||"—"} | ${p.uptime??""} | ${p.anonymity||"—"}`;}).join("\n");}
api.runtime.onMessage.addListener((msg,sender,sendResponse)=>{(async()=>{switch(msg?.action){
 case"state":return getState();case"storageText":return storageText(await getState());case"validateStorage":{const parsed=parseManualText(msg.text||"");return{ok:true,valid:parsed.proxies.length,invalid:parsed.invalid,capped:parsed.proxies.length>77};}case"replaceStorage":return replaceFromText(msg.text||"");case"add":return addProxy(msg.proxy||{});case"testTop":return testTop(msg.count||7,msg.country||"ALL",msg.limit||77);case"activate":return activate(msg.id);case"chooseTop":return chooseTop();case"disable":return disable();case"countries":return countries(await getState());
 case"setCountry":{const s=await getState();s.selectedCountry=msg.country||"ALL";await saveState(s);return s;}
 case"delete":{const s=await getState();s.proxies=s.proxies.filter(p=>p.id!==msg.id);s.hotIds=s.hotIds.filter(id=>id!==msg.id);if(s.activeId===msg.id){await setBrowserProxy(null);s.activeId=null;s.enabled=false;}await saveState(s);return s;}
 case"clear":{const s=await getState();await setBrowserProxy(null);s.proxies=[];s.hotIds=[];s.activeId=null;s.enabled=false;await saveState(s);return s;}
 case"settings":{const s=await getState();s.settings={...s.settings,...msg.settings};s.settings.topCount=Math.min(77,Math.max(1,Number(s.settings.topCount)||7));s.settings.testBatch=Math.min(77,Math.max(1,Number(s.settings.testBatch)||7));s.settings.maxImport=77;await saveState(s);return s;}
 case"reminder":{const s=await getState(),every=Number(s.settings.reminderHours||2)*3600000,due=!!s.enabled&&!!s.activeId&&Date.now()-Number(s.reminder.lastChanged||0)>=every;return{due,hours:Number(s.settings.reminderHours||2)};}
 default:return{ok:false,error:"Unknown action"};}})().then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e||"Service worker error")}));return true;});
if(api.alarms?.create){api.alarms.create("proxy-rotation-check",{periodInMinutes:15});api.alarms.onAlarm?.addListener(async alarm=>{if(alarm.name!=="proxy-rotation-check")return;const s=await getState();if(!s.enabled||!s.activeId||!api.notifications?.create)return;const every=Number(s.settings.reminderHours||2)*3600000;if(Date.now()-Number(s.reminder.lastChanged||0)<every)return;if(Date.now()-Number(s.reminder.lastNotified||0)<55*60000)return;s.reminder.lastNotified=Date.now();await saveState(s);try{await api.notifications.create("proxy-rotation",{type:"basic",title:"Kaliyankattu Yakshi",message:"Rotation reminder: change your active proxy.",iconUrl:api.runtime.getURL("icon.png")});}catch{}});}
